-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nba
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coaches`
--

DROP TABLE IF EXISTS `coaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coaches` (
  `CoachID` int(11) NOT NULL AUTO_INCREMENT,
  `CoachName` varchar(45) DEFAULT NULL,
  `CoachingRecord` varchar(45) DEFAULT NULL,
  `NumChampionships` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`CoachID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coaches`
--

LOCK TABLES `coaches` WRITE;
/*!40000 ALTER TABLE `coaches` DISABLE KEYS */;
INSERT INTO `coaches` VALUES (1,'Mike Budenholzer','209-187','0'),(2,'Brad Stevens','212-184','0'),(3,'Kenny Atkinson','41-109','0'),(4,'Steve Clifford','189-207','0'),(5,'Fred Hoiberg','106-125','0'),(6,'Tyronn Lue','117-73','1'),(7,'Rick Carlisle','435-355','1'),(8,'Michael Malone','110-122','0'),(9,'Stan Van Gundy','143-170','0'),(10,'Steve Kerr','259-55','2'),(11,'Mike D\'Antoni','108-41','0'),(12,'Nate McMillan','82-68','0'),(13,'Doc Rivers','254-140','1'),(14,'Luke Walton','57-93','0'),(15,'J.B. Bickerstaff','11--37','0'),(16,'Erik Spolestra','476-315','2'),(17,'Joe Prunty','16-12','0'),(18,'Tom Thibodeau','71-80','0'),(19,'Alvin Gentry','103-128','0'),(20,'Jeff Hornacek','55-95','0'),(21,'Billy Donovan','143-91','0'),(22,'Frank Vogel','50-101','0'),(23,'Brett Brown','111-283','0'),(24,'Jay Triano','19-47','0'),(25,'Terry Stotts','264-213','0'),(26,'Dave Joerger','54-97','0'),(27,'Gregg Popovich','1,188-536','5'),(28,'Dwane Casey','311-232','0'),(29,'Quin Snyder','167-147','0'),(30,'Scott Brooks','88-63','0');
/*!40000 ALTER TABLE `coaches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-09 12:49:22
