-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nba
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stadium`
--

DROP TABLE IF EXISTS `stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stadium` (
  `StadiumID` int(11) NOT NULL AUTO_INCREMENT,
  `StadiumName` varchar(45) DEFAULT NULL,
  `Location` varchar(45) DEFAULT NULL,
  `MaxCapacity` varchar(45) DEFAULT NULL,
  `HomeTeam` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`StadiumID`),
  KEY `HomeTeam_idx` (`HomeTeam`),
  CONSTRAINT `HomeTeam` FOREIGN KEY (`HomeTeam`) REFERENCES `teams` (`TeamName`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium`
--

LOCK TABLES `stadium` WRITE;
/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` VALUES (1,'Wisconsin Entertainment Center','Milwaukee, WI','17,500','Milwaukee Bucks'),(2,'Target Center','Minneapolis, MN','19,356','Minnesota Timberwolves'),(3,'New Orleans Arena','New Orleans, LA','17,791','New Orleans Pelicans'),(4,'Staples Center','Los Angelas, CA','21,000','Los Angeles Clippers'),(5,'Quicken Loans Arena','Cleveland, OH','20,562','Cleveland Cavaliers'),(6,'Wells Fargo Center','Philadelphia, PA','20,328','Philadelphia 76\'ers'),(7,'Chesapeake Energy Center','Oklahoma City, OK','18,203','Oklahoma City Thunder'),(8,'AT&T Center','San Antonio, TX','18,418','San Antonio Spurs'),(9,'FedEx Forum','Memphis, TN','18,119','Memphis Grizzlies'),(10,'Philips Arena','Atlanta, GA','18,118','Atlanta Hawks'),(11,'Toyota Center','Houston, TX','18,055','Houston Rockets'),(12,'Barclays Center','Brooklyn, NY','17,732','Brooklyn Nets'),(13,'Oracle Arena','Oakland, CA','19,596','Golden State Warriros'),(14,'Pepsi Center','Denver, CO','19,155','Denver Nuggets'),(15,'Amway Center','Orlando, FL','18,846','Orlando Magic'),(16,'American Airlines Arena','Miami, FL','19,600','Miami Heat'),(17,'American Airlines Center','Dallas, TX','19,200','Dallas Mavericks'),(18,'Air Canada Centre','Toranto, Ontario','19,800','Toranto Raptors'),(19,'Staples Center','Los Angelas, CA','18,997','Los Angeles Lakers'),(20,'United Center','Chicago, IL','20,917','Chicago Bulls'),(21,'Bankers Life Fieldhouse','Indianapolis, IN','17,923','Indiana Pacers'),(22,'TD Bank Garden','Boston, MA','18,624','Boston Celtics'),(23,'Madison Square Garden','New York','19,812','New York Knicks'),(24,'Capital One Arena','Washington, D.C','20,356','Washington Wizards'),(25,'Golden 1 Center','Sacramento, CA','17,608','Sacramento Kings'),(26,'Little Caesars Arena','Detroit, MI','20,491','Detroit Pistons'),(27,'Moda Center','Portland, OR','19,980','Portland Trail Blazers'),(28,'Spectrum Center','Charlotee, NC','19,077','Charlotee Hornets'),(29,'Talking Stick Resort Arena','Phoenix, AR','18,422','Phoenix Suns'),(30,'Vivint Smart Home Arena','Salt Lake City, UT','18,303','Utah Jazz');
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-09 12:49:22
